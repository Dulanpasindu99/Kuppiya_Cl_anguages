
#include<stdio.h>

int main()
{
    printf("Hellow world\n");

    //This is a single line Comment

    /* This
    is
    a
    multi line
    comment */

    return 0;
}
