#include<stdio.h>

int main()
{
    int a = 5;
    char b = 'A';
    float c = 5.1234;
    double d = 6.789;

    printf("%d\n",a); // %d use for integer value
    printf("%c\n",b); // %c use for char value
    printf("%f\n",c); // %f use for float value
    printf("%f\n",d); // %f also use for double value

    return 0;

}
