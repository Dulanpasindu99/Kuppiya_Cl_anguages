
#include<stdio.h>

int main()
{
    char name[10];
    char sub_grade;
    int index_no;

    printf("Enter Your name : ");
    scanf("%s",&name);

    printf("Enter Your sub_grade : ");
    scanf(" %c",&sub_grade);

    printf("Enter Your index_no : ");
    scanf("%d",&index_no);

    printf("\n\n Your name is : %s",name);
    printf("\n Your sub_grade is: %c",sub_grade);
    printf("\n Your index_no is: %d",index_no);

    return 0;

}
