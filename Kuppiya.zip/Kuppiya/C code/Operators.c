
#include<stdio.h>

int main()
{
    //Arithmetic Operators***************************************

    /*int a = 10+5;
    int b = 5-6;
    int c = 7*2;
    float d = (float)9/7; // casting
    int e = 7%3;

    printf("%d\n",a);
    printf("%d\n",b);
    printf("%d\n",c);
    printf("%f\n",d);
    printf("%d\n",e);

    return 0;*/


    //Assignment Operators**************************************************

    /*int x=3,y=10;
    x=y;
    printf("%d",x);*/

    //Logical Operators - AND - &&     OR - ||       NOT - !    ************

    /*int a = 5;
    int b = 20;


    if ( a && b ) {    //AND
      printf("Line 1 - Condition is true\n" );
   }

    if ( a || b ) {     //OR
      printf("Line 2 - Condition is true\n" );
   }

    // lets change the value of  a and b
    a = 0;
    b = 10;

    if ( a && b ) {
      printf("Line 3 - Condition is true\n" );
    } else {
      printf("Line 3 - Condition is not true\n" );
    }

    if ( !(a && b) ) {      //NOT
      printf("Line 4 - Condition is true\n" );
    }
    return 0;*/

    //Relational Operators*******************************

    /*int a = 21;
    int b = 10;
    int c ;

    if( a == b ) {
      printf("Line 1 - a is equal to b\n" );
    } else {
      printf("Line 1 - a is not equal to b\n" );
    }

    if ( a < b ) {
      printf("Line 2 - a is less than b\n" );
    } else {
      printf("Line 2 - a is not less than b\n" );
    }

    if ( a > b ) {
      printf("Line 3 - a is greater than b\n" );
    } else {
      printf("Line 3 - a is not greater than b\n" );
    }

    //Lets change value of a and b
    a = 5;
    b = 20;

    if ( a <= b ) {
      printf("Line 4 - a is either less than or equal to  b\n" );
    }

    if ( b >= a ) {
      printf("Line 5 - b is either greater than  or equal to b\n" );
    }

    return 0;*/

    //Increment / Decrement***************************************

    /*int a = 19;
    printf("%d\n",++a); //19+1
    printf("%d\n",a--); //20-1 but answer is 20
    printf("%d\n",--a); //19-1
    printf("%d\n",a++); //18+1 but answer is 18
    */

    /*int a=19;
    //a++;
    printf("%d\n",a++);
    --a;
    printf("%d\n",a);

    return 0;*/

}
