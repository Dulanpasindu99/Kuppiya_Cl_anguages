#include<stdio.h>

int main()
{
    //continue************************
    int z;
    for(z=0;z<=10;z++)
    {
        if(z==5)
        continue;
        printf("%d\n",z);
    }
    return 0;

    //break **************************
    /*char x='+';
    int a=10,b=5;
       switch(x)
       {
        case '+' :printf("%d\n",a+b);break;
        case '-' :printf("%d\n",a-b);break;
        case '*' :printf("%d\n",a*b);break;
        case '/' :printf("%f\n",(float)a/b);break;
        default:printf("Error");
       }
    return 0;*/
}
