
#include<stdio.h>

int main()
{
    int no=1;
    do{
        printf("%d\n",no); //definitely run this part at once
        no++;
    }while(no<5);

    return 0;
}
