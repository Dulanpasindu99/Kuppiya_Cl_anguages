
#include<stdio.h>

int main()
{
    int marks = 6;
    if(marks>5)
        printf("pass");
    else
        printf("fail");

    // else if
    /*int marks = 65;
    if(marks>=90)
        printf("A pass");
    else if(marks>=65) //If we have more choices
        printf("B pass");
    else
        printf("C pass");*/

    return 0;

}
