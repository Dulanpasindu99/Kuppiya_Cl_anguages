
#include<stdio.h>

int main()
{
    int count=6;
    while(count<=5)
    {
        printf("thada thada\n");
        count++;
    }
    return 0;
}
